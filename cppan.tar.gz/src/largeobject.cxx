/*-------------------------------------------------------------------------
 *
 *   FILE
 *	largeobject.cxx
 *
 *   DESCRIPTION
 *      Implementation of the Large Objects interface
 *   Allows access to large objects directly, or though I/O streams
 *
 * Copyright (c) 2003-2015, Jeroen T. Vermeulen <jtv@xs4all.nl>
 *
 * See COPYING for copyright license.  If you did not receive a file called
 * COPYING with this source code, please notify the distributor of this mistake,
 * or contact the author.
 *
 *-------------------------------------------------------------------------
 */
#include "pqxx/compiler-internal.hxx"

#include <algorithm>
#include <cerrno>
#include <stdexcept>

#include "libpq-fe.h"

//#include "libpq/libpq-fs.h"
/// Copied from libpq/libpq-fs.h so we don't need that header anymore
#define INV_WRITE		0x00020000
/// Copied from libpq/libpq-fs.h so we don't need that header anymore
#define INV_READ		0x00040000

#include "pqxx/largeobject"

#include "pqxx/internal/gates/connection-largeobject.hxx"


using namespace pqxx::internal;

namespace
{

inline int StdModeToPQMode(std::ios::openmode mode)
{
  return ((mode & std::ios::in)  ? INV_READ  : 0) |
         ((mode & std::ios::out) ? INV_WRITE : 0);
}


inline int StdDirToPQDir(std::ios::seekdir dir) PQXX_NOEXCEPT
{
  // TODO: Figure out whether seekdir values match C counterparts!
#ifdef PQXX_SEEKDIRS_MATCH_C
  return dir;
#else
  int pqdir;
  switch (dir)
  {
      case std::ios::beg: pqdir=SEEK_SET; break;
  case std::ios::cur: pqdir=SEEK_CUR; break;
  case std::ios::end: pqdir=SEEK_END; break;

  /* Added mostly to silence compiler warning, but also to help compiler detect
   * cases where this function can be optimized away completely.  This latter
   * reason should go away as soon as PQXX_SEEKDIRS_MATCH_C works.
   */
  default: pqdir = dir; break;
  }
  return pqdir;
#endif
}


} // namespace


pqxx::largeobject::largeobject() PQXX_NOEXCEPT :
  m_ID(oid_none)
{
}


pqxx::largeobject::largeobject(dbtransaction &T) :
  m_ID()
{
  m_ID = lo_creat(RawConnection(T), INV_READ|INV_WRITE);
  if (m_ID == oid_none)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    throw failure("Could not create large object: " + Reason(err));
  }
}


pqxx::largeobject::largeobject(dbtransaction &T, const std::string &File) :
  m_ID()
{
  m_ID = lo_import(RawConnection(T), File.c_str());
  if (m_ID == oid_none)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    throw failure("Could not import file '" + File + "' to large object: " +
	Reason(err));
  }
}


pqxx::largeobject::largeobject(const largeobjectaccess &O) PQXX_NOEXCEPT :
  m_ID(O.id())
{
}


void pqxx::largeobject::to_file(dbtransaction &T,
	const std::string &File) const
{
  if (lo_export(RawConnection(T), id(), File.c_str()) == -1)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    throw failure("Could not export large object " + to_string(m_ID) + " "
	                "to file '" + File + "': " +
			Reason(err));
  }
}


void pqxx::largeobject::remove(dbtransaction &T) const
{
  if (lo_unlink(RawConnection(T), id()) == -1)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    throw failure("Could not delete large object " + to_string(m_ID) + ": " +
	Reason(err));
  }
}


pqxx::internal::pq::PGconn *pqxx::largeobject::RawConnection(
	const dbtransaction &T)
{
  return gate::connection_largeobject(T.conn()).RawConnection();
}


std::string pqxx::largeobject::Reason(int err) const
{
  if (err == ENOMEM) return "Out of memory";
  if (id() == oid_none) return "No object selected";

  char buf[500];
  return std::string(strerror_wrapper(err, buf, sizeof(buf)));
}


pqxx::largeobjectaccess::largeobjectaccess(dbtransaction &T, openmode mode) :
  largeobject(T),
  m_Trans(T),
  m_fd(-1)
{
  open(mode);
}


pqxx::largeobjectaccess::largeobjectaccess(dbtransaction &T,
					   oid O,
					   openmode mode) :
  largeobject(O),
  m_Trans(T),
  m_fd(-1)
{
  open(mode);
}


pqxx::largeobjectaccess::largeobjectaccess(dbtransaction &T,
					   largeobject O,
					   openmode mode) :
  largeobject(O),
  m_Trans(T),
  m_fd(-1)
{
  open(mode);
}


pqxx::largeobjectaccess::largeobjectaccess(dbtransaction &T,
					   const std::string &File,
					   openmode mode) :
  largeobject(T, File),
  m_Trans(T),
  m_fd(-1)
{
  open(mode);
}


pqxx::largeobjectaccess::size_type
pqxx::largeobjectaccess::seek(size_type dest, seekdir dir)
{
  const size_type Result = cseek(dest, dir);
  if (Result == -1)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    throw failure("Error seeking in large object: " + Reason(err));
  }

  return Result;
}


pqxx::largeobjectaccess::pos_type
pqxx::largeobjectaccess::cseek(off_type dest, seekdir dir) PQXX_NOEXCEPT
{
  return lo_lseek(RawConnection(), m_fd, int(dest), StdDirToPQDir(dir));
}


pqxx::largeobjectaccess::pos_type
pqxx::largeobjectaccess::cwrite(const char Buf[], size_type Len) PQXX_NOEXCEPT
{
  return
    std::max(
	lo_write(RawConnection(), m_fd,const_cast<char *>(Buf), size_t(Len)),
        -1);
}


pqxx::largeobjectaccess::pos_type
pqxx::largeobjectaccess::cread(char Buf[], size_type Bytes) PQXX_NOEXCEPT
{
  return std::max(lo_read(RawConnection(), m_fd, Buf, size_t(Bytes)), -1);
}


pqxx::largeobjectaccess::pos_type
pqxx::largeobjectaccess::ctell() const PQXX_NOEXCEPT
{
  return lo_tell(RawConnection(), m_fd);
}


void pqxx::largeobjectaccess::write(const char Buf[], size_type Len)
{
  const long Bytes = cwrite(Buf, Len);
  if (Bytes < Len)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    if (Bytes < 0)
      throw failure("Error writing to large object #" + to_string(id()) + ": " +
	Reason(err));
    if (Bytes == 0)
      throw failure("Could not write to large object #" + to_string(id()) +
	": " + Reason(err));

    throw failure("Wanted to write " + to_string(Len) + " bytes "
	"to large object #" + to_string(id()) + "; "
	"could only write " + to_string(Bytes));
  }
}


pqxx::largeobjectaccess::size_type
pqxx::largeobjectaccess::read(char Buf[], size_type Len)
{
  const long Bytes = cread(Buf, Len);
  if (Bytes < 0)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    throw failure("Error reading from large object #" + to_string(id()) +
	": " + Reason(err));
  }
  return Bytes;
}


void pqxx::largeobjectaccess::open(openmode mode)
{
  m_fd = lo_open(RawConnection(), id(), StdModeToPQMode(mode));
  if (m_fd < 0)
  {
    const int err = errno;
    if (err == ENOMEM) throw std::bad_alloc();
    throw failure("Could not open large object " + to_string(id()) + ": " +
	Reason(err));
  }
}


void pqxx::largeobjectaccess::close() PQXX_NOEXCEPT
{
  if (m_fd >= 0) lo_close(RawConnection(), m_fd);
}


pqxx::largeobjectaccess::size_type pqxx::largeobjectaccess::tell() const
{
  const size_type res = ctell();
  if (res == -1) throw failure(Reason(errno));
  return res;
}


std::string pqxx::largeobjectaccess::Reason(int err) const
{
  return (m_fd == -1) ? "No object opened" : largeobject::Reason(err);
}


void pqxx::largeobjectaccess::process_notice(const std::string &s)
	PQXX_NOEXCEPT
{
  m_Trans.process_notice(s);
}
